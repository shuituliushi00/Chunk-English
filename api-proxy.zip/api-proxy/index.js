const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(cors());
app.use(express.json());

// DeepSeek代理端点
app.post('/proxy/deepseek', async (req, res) => {
  try {
    const response = await axios.post('https://api.deepseek.com/v1/chat/completions', {
      model: "deepseek-chat",
      messages: [{ role: "user", content: req.body.prompt }]
    }, {
      headers: { 
        Authorization: `Bearer ${process.env.DEEPSEEK_KEY}`,
        "Content-Type": "application/json"
      }
    });
    res.json(response.data);
  } catch (error) {
    console.error('代理错误:', error);
    res.status(500).json({ error: "API请求失败" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`代理服务运行中:${PORT}`));